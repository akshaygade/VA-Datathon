# Open Data Analysis To Curb Opioid Crisis
## [Datathon 2017](http://data.virginia.gov/datathon-2017)

This repository contains the work we did for the opioid crisis datathon.

<img src="https://github.com/saurabh-rao/va-datathon-2017/blob/master/pictureWithGOvernorTerryMcAuliffe.jpg" width="500px" height="350px"/>
